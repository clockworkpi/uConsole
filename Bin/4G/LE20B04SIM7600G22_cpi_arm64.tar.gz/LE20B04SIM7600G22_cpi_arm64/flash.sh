sudo   fastboot/bin/fastboot flash aboot appsboot.mbn
sudo   fastboot/bin/fastboot flash rpm rpm.mbn
sudo   fastboot/bin/fastboot flash sbl sbl1.mbn
sudo   fastboot/bin/fastboot flash tz tz.mbn
sudo   fastboot/bin/fastboot flash modem modem.img
sudo   fastboot/bin/fastboot flash boot boot.img
sudo   fastboot/bin/fastboot flash system system.img
sudo   fastboot/bin/fastboot flash recovery  recovery.img
sudo   fastboot/bin/fastboot flash recoveryfs recoveryfs.img

sudo   fastboot/bin/fastboot reboot
